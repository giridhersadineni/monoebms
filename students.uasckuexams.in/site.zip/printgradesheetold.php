<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->

<style>
*{
    margin:0px;
    padding:0px;
    font-family:arial;
    font-weight:bold;
    font-size:11.2px;
}
table{
   width: 100%;
/*border:1px solid;*/
}

/*td{*/
/*    border:1px solid;*/
   
/*}*/

</style>
</head>
<?php

include "config.php";
//check connection

$conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);

//check connection
if ($conn->connect_error){
    die("connection failed:".mysqli_connect_error());
}
else{
$res = "select * from  students where haltckt=".$_GET['ht'];
$result = $conn->query($res);
// echo $res;

$exam="select * from examsmaster where EXID='".$_GET['exid']."'";
$examname=mysqli_query($conn,$exam);

//echo $exam;

$examtype="";
if($result->num_rows>0){

while($row=$result->fetch_assoc())
 { 
     
     
  break;
 }
}
if($examname->num_rows>0){
while($ex=$examname->fetch_assoc())
 { 
  break;
 }
}
}
?>
  
<body style='min-width:20cm;max-width:20cm;margin-left:auto;margin-right:auto;margin-top:0px;padding:0px;'>
<table style="min-width:20cm;max-width:20cm;margin-top:0.55cm;">
<tr>
  <td style="padding-left:2.7cm;width:13cm;vertical-align:top;">
      <?php 
      echo '<p style="padding-bottom:0.1cm;">'.$ex['EXAMNAME']."</p>";
      echo '<p style="padding-bottom:0.1cm;">'.$row['sname'].'<p>';
      echo '<p style="padding-bottom:0.1cm;">'.$row['mname'].'<p>';
      echo '<p>'.$row['fname'].'<p>';
      ?>
     </td>

<td style="vertical-align:top;">
    <?php 
    echo '<p style="padding-bottom:0.1cm;">';
    echo date("d/m/Y");
    echo "</p>";
    echo '<p style="padding-bottom:0.1cm;">'.$row['haltckt']."</p>";
    echo '<p>'.$row['aadhar']."</p>";
    ?>
    </td>
</tr>
</table>
<br>
<br>
<br><br>

<table style="width:19cm;margin-top:4px;max-height:3cm;min-height:3cm;vertical-align:top;" >
<tr>
<?php 
include "config.php";
//check connection

$conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);

//check connection
if ($conn->connect_error){
    die("connection failed:".mysqli_connect_error());
}
else{
$sql = "select * from  RESULTS where EXAMID=".$_GET['exid']." AND HALLTICKET='".$_GET['ht']."'";
//echo $sql;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->

<style>
*{
    margin:0px;
    padding:0px;
    font-family:arial;
    font-weight:bold;
    font-size:11.2px;
}
table{
   width: 100%;
/*border:1px solid;*/
}
table tr{
    vertical-align:top;
}

/*td{*/
/*    border:1px solid;*/
   
/*}*/

</style>
</head>
<?php

include "config.php";
//check connection

$conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);

//check connection
if ($conn->connect_error){
    die("connection failed:".mysqli_connect_error());
}
else{
$res = "select * from  students where haltckt=".$_GET['ht'];
$result = $conn->query($res);


$exam="select * from examsmaster where EXID=".$_GET['examid'];

$examname=mysqli_query($conn,$exam);
//echo $exam;

$examtype="";
if($result->num_rows>0){

while($row=$result->fetch_assoc())
 { 
     
     
  break;
 }
}
if($examname->num_rows>0){
while($ex=$examname->fetch_assoc())
 { 
  break;
 }
}
}
?>
  
<body style='min-width:20cm;max-width:20cm;margin-left:auto;margin-right:auto;margin-top:0px;padding:0px;'>

<table style="min-width:20cm;max-width:20cm;margin-top:0.55cm;">
<tr>
  <td style="padding-left:2.7cm;width:13cm;vertical-align:top;">
      <?php 
      echo '<p style="padding-bottom:0.1cm;">'.$ex['EXAMNAME']."</p>";
      echo '<p style="padding-bottom:0.1cm;">'.$row['sname'].'<p>';
      echo '<p style="padding-bottom:0.1cm;">'.$row['mname'].'<p>';
      echo '<p>'.$row['fname'].'<p>';
      ?>
     </td>

<td style="vertical-align:top;">
    <?php 
    echo '<p style="padding-bottom:0.1cm;">';
    echo date("d/m/Y");
    echo "</p>";
    echo '<p style="padding-bottom:0.1cm;">'.$row['haltckt']."</p>";
    echo '<p>'.$row['aadhar']."</p>";
    ?>
    </td>
</tr>
</table>
<br>
<br>
<br>
<table style="width:19cm;margin-top:4px;max-height:3cm;min-height:3cm;vertical-align:top;" >
<tr>
<?php 
include "config.php";
//check connection

$conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);

//check connection
if ($conn->connect_error){
    die("connection failed:".mysqli_connect_error());
}
else{
$sql = "select * from  RESULTS where EID=".$_GET['id']." and HALLTICKET=".$_GET['ht'];
//echo $sql;
$gpt=0;
 $totalcredit=0;
 $passed=1;
 $examtype="";
$result = $conn->query($sql);

if($result->num_rows>0){

while($row=$result->fetch_assoc())
 { 
   
   // print_r($row);
    //echo "<br>";
        echo "<tr style='vertical-align:center;padding:4px;'>";
        echo "<td style=padding-right:4cm;font-size:12px; margin-bottom:0px;>".strtoupper($row['PAPERNAME'])."</td>";
     echo "<td style='width:3cm;font-size:12px;margin-bottom:0px;text-align:center;' >" . $row['CREDITS'] . "</td>";
       echo  "<td style='font-size:12px;margin-bottom:0px; text-align:center;' >" . $row['GRADE'] . "</td>";
     
   $gpt+=$row['GPC'];
   $totalcredit+=$row['CREDITS'];
   if($row['RESULT']=="F" || $row['RESULT']=="AB"){
       $passed=0;
    }
     echo "</tr>";
}
}
}
?>
<?php
mysqli_close($conn);
?>
</tr>
</table>

<!--<br><br><br><br><br><br><br><br>-->
<!--<table style="margin-top:30px;max-height:0cm;min-height:0cm;">-->
 <style>
    .result{
        /*border:1px solid;*/
        position:absolute;
        top:10.6cm;
       
    }
    
</style>
<table  class='result' style="max-height:0cm;min-height:0cm;"> 
<?php

echo "<tr><td colspan='3'style='font-size:12px;padding-left:1.5cm;'>"; 
if($passed==1){ 
    echo "PASSED";
    } else {
        echo "PROMOTOED";
    }";</td></tr>";
    echo "<br>";
 echo "<tr><td colspan='3'style='font-size:12px;padding-left:1.5cm;'>";
 
 echo round($gpt/$totalcredit,PHP_ROUND_HALF_UP);
 
 echo "</td></tr>";

?>    
<?php
mysqli_close($conn);
?>
</table>
</body>

</html>
$gpt="select * from  gpas where EXAMID=".$_GET['exid']." AND HALLTICKET='".$_GET['ht']."' ORDER BY CREDITS DESC";
$gpts = $conn->query($gpt);


$passed=1;
// echo $passed;
$gpt=0;
if($gpts->num_rows>0){

while($rows=$gpts->fetch_assoc())
 { 
   
   $gpt+=$rows['SGPA'];
  // echo $gpt;
   if($rows['RESULT']=="R" || $rows['RESULT']=="AB")
   {
       $passed=0;
    }
}
}




 $examtype="";
 
$result = $conn->query($sql);

if($result->num_rows>0){

while($row=$result->fetch_assoc())
 { 
        echo "<tr style='vertical-align:center;padding:4px;'>";
        echo "<td style=padding-right:4cm;font-size:12px; margin-bottom:0px;>".strtoupper($row['PAPERNAME'])."</td>";
     echo "<td style='width:3cm;font-size:12px;margin-bottom:0px;text-align:center;' >" . $row['CREDITS'] . "</td>";
       echo  "<td style='font-size:12px;margin-bottom:0px; text-align:center;' >" . $row['GRADE'] . "</td>";
     
     echo "</tr>";
}
}
}
?>
<?php
mysqli_close($conn);
?>
</tr>

</table>
<br>
<style>
    .result{
        /*border:1px solid;*/
        position:absolute;
        top:10.6cm;
       
    }
    
</style>
<table  class='result' style="max-height:0cm;min-height:0cm;"> 
<?php
echo "<tr><td colspan='3'style='font-size:12px;padding-left:1.5cm;'>"; 

if($passed==1){ 
    
    echo "PASSED";
    } else {
        echo "PROMOTOED";
    }";
    
    </td></tr>";
    echo "<br>";
 echo "<tr><td colspan='3'style='font-size:12px;padding-left:1.5cm;'>";
 
 echo $gpt;
 
 echo "</td></tr>";

?>    
<?php
mysqli_close($conn);
?>
</table>
</body>

</html>