               
<br>
<nav class="sidebar-nav">
<ul id="sidebarnav">
<nav class="sidebar-nav" style="background:#002a5c">

<li><a href="dashboard.php"> <i class="fa fa-home"></i><font color="white">Dashboard </font></a></li>
<li><a href="welcome.php" aria-expanded="false"> <i class="fa fa-home"></i><font color="black">Home </font></a></li>
<li> <a class="has-arrow" href="#" aria-expanded="false"> <i class="fa fa-asterisk"></i> <span class="hide-menu"><font color="white">Edit Masters</font></span></a>
<ul aria-expanded="false" class="collapse">
<li><a href="papers.php"> <i class=""></i> <font color="white"> Papers</font></a></li>
<li><a href="examtable.php"> <i class=""></i> <font color="white">Exams</font></a></li>
</ul>
</li>
<li> <a class="has-arrow" href="#" aria-expanded="false"> <i class="fa fa-registered"></i> <span class="hide-menu"><font color="white">Nominal Rolls</font></span></a>
<ul aria-expanded="false" class="collapse">

<li><a href="enrolledview.php"> <i class=""></i> <font color="white"><font color="white"> Enrolled Students</font></a></li>
<li><a href="revaluationview.php"> <i class=""></i> <font color="white"><font color="white"> Revaluation Students</font></a></li>
<li><a href="viewenrollments.php"> <i class=""></i> <font color="white"><font color="white"> Revaluation Enrollments</font></a></li>
<li><a href="markpayment.php"> <i class=""></i> <font color="white">Mark Fee Payment</font></a></li>
<li><a href="gendform.php"> <i class=""></i> <font color="white">D-Form Generation</font></a></li>
<li><a href="genattend.php"> <i class=""></i> <font color="white">Attendance Sheet</font></a></li>
<li><a href="form.php"> <i class=""></i> <font color="white">Answer Script Coding</font></a></li>
<li><a href="viewresult.php"> <i class=""></i> <font color="white">Result Processing</font></a></li>
</ul>
</li>
<li> <a class="has-arrow" href="#" aria-expanded="false"> <i class="fa fa-dollar-sign"></i> <span class="hide-menu"><font color="white">Fee Payment</font></span></a>
<ul aria-expanded="false" class="collapse">
<li><a href="markpayment.php"> <i class=""></i> <font color="white"> Mark Fee Payment</font></a></li>
<li><a href="revaluationmpayment.php"> <i class=""></i> <font color="white">Mark Revaluation Payment</font></a></li>
<li><a href="transcation.php"><i class=" fa fa-book"></i><font color="white"> Transcations Details</font> </a></li>
</ul>
</li>
<li> <a class="has-arrow" href="#" aria-expanded="false"><i class="fa fa-scroll"></i><span class="hide-menu"><font color="white">Reports</font></span></a>
<ul aria-expanded="false" class="collapse">
<li><a href="viewenrolled.php"> <i class="fa fa-file"></i> <font color="white"> Print Memo</font></a></li>
<li><a href="printofflinememo.php"> <i class="fa fa-file"></i> <font color="white"> Print Offline Memo</font></a></li>
<li><a href="consolidatedmemo.php"> <i class=""></i> <font color="white"> Consolidated Memo</font></a></li>
<li><a href="bosreport.php"> <i class="fa fa-card"></i> <font color="white"> BOS Report</font></a></li>
<li><a href="tabulation.php"> <i class="fa fa-table"></i> <font color="white"> Tabulation Report</font></a></li>
<li><a href="oldtabreport.php" target="blank"> <i class="fa fa-table"></i> <font color="white">Old Tabulation Report</font></a></li>
<li><a href="revresult.php"> <i class="fa fa-card"></i> <font color="white">Revaluation Result</font></a></li>
<li><a href="oldmemogen.php"> <i class="fa fa-file"></i> <font color="white">Print Old memo</font></a></li>
</ul>
</li>
<li> <a class="has-arrow" href="#" aria-expanded="false"><i class="fa fa-scroll"></i><span class="hide-menu"><font color="white">View Student</font></span></a>
<ul aria-expanded="false" class="collapse">Students
<li><a href="viewstudents.php"> <i class="fa fa-graduation-cap"></i><font color="white">Student </font></a></li>
<!--<li><a href="/ebms/backoffice/registerstudent.php"> <i class="fa fa-graduation-cap"></i><font color="white"> Register student</font></a></li>-->

</ul>
</li> 


                              


<li><a href="changepswd.php"> <i class="fa fa-key"></i><font color="white"> Change Password</font></a></li>

<!--<li><a href="email.php"><i class="fa fa-envelope"></i><font color="white"> Email </font></a></li>-->

<li><a href="index.php?loggedout=true"><i class="fa fa-angle-double-right"></i><font color="white"> Logout </font></a></li>
</ul>
</nav>
 