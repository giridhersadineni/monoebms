<script>
   // var p="july2021";
    // r=prompt("Enter Report Password");r!=p && (window.location.href="https://uascku.ac.in/404");
</script>
<?php 
$db= isset($_GET['db']) ? $_GET['db'] :"atech_ebms" ;
//echo $db;
include "domainfunctions.php";
function consolidatedreport(
    $papers
) {
    $marks_sec = 0;
    $totalmarks = 0;
    $credit_total = 0;
    $gpc_total = 0;
    $gpcc_total = 0;
    $percentages = array();
    $cgpa_percentages = array();
    $failed_count = 0;
    $passedbyfloatation = false;
    $failedpapers = array();
    $examresult="P";
    foreach ($papers as $paper) {
        if ($paper['GRADE'] == 'EX') {
            continue;
        }

        if ($paper['RESULT'] == 'F') {
            $failed_count++;
            $examresult="R";
            array_push($failedpapers, $paper);
        }
        if ($paper['RESULT'] == 'AB') {
            $failed_count++;
            $examresult="R";
            array_push($failedpapers, $paper);
        }
        
        
        if ($paper['STATUS'] == "FL" || $paper['STATUS'] == "FL-" || $paper['STATUS'] == "FL AC") {
            $passedbyfloatation = $paper['STATUS'];
        }
        $gpc_total += $paper['GPC'];
        $credit_total += $paper['CREDITS'];
        $marks_sec += $paper['MARKS'];
        $totalmarks += $paper['TOTALMARKS'];
    }
    $result = array();
    $result['MARKS'] = $marks_sec;
    $result['TOTAL'] = $totalmarks;
    $result['gpc_total'] = $gpc_total;
    $result['credits'] = $credit_total;
    $result['SGPA'] = $gpc_total / $credit_total;
    $result['OGPA'] = $gpc_total / $credit_total;
    $per = $marks_sec / $totalmarks * 100;
    $cper = $result['OGPA'] * 10;
    $result['failed_count'] = $failed_count;
    $result['PERCENTAGE'] = $per;
    $result['cf'] = $per - $cper;
    if ($passedbyfloatation) {
        $result['passedbyfloatation'] = $passedbyfloatation;
    } else {
        $result['passedbyfloatation'] = "";
    }
    $result['RESULT']=$examresult;
    return $result;
}
?>
<style>
* {
font-family: arial;
}
.resulttable {
    margin-top: 0px;
    padding-bottom: 6px;
    width: 100%;
    page-break-inside: avoid;
}
hr {
    border: 1px dashed;
    margin-bottom: 2px;
}
td {
    font-size: <?php echo $_GET['fontsize']; ?>;
}
.student-title {
    padding: 0px;
    margin: 0px;
}
.watermark {
    display: none;
}
@media only print {
.watermark {
height: 100vh;
width: 100%;
display: flex;
flex-direction: row;
align-items: center;
justify-content: center;
position: fixed;
top: 0;
left: 0;
z-index: -1000;
}
}
</style>
<h2 style="text-align:center">
    FLOATATION REPORT
</h2>
<H3 style="text-align:center">    
EXAMINATION BRANCH 
<br>
 UNIVERSITY ARTS & SCIENCE COLLEGE
</H3>
<table style="width:100%" class="report">
    <tbody>
        <?php
        set_time_limit(1000);
        ini_set('display_errors', 1);
        include "../config.php";
        $conn = mysqli_connect($servername, $dbuser, $dbpwd, $db);
        if ($conn->connect_error) {
        die("connection failed:" . mysqli_connect_error());
        } else {
        $getstudents = "select DISTINCT(HALLTICKET),EXAMID,students.* from  RESULTS_STAGE left join students on HALLTICKET=haltckt WHERE HALLTICKET LIKE '19022%' OR HALLTICKET LIKE '18022%'  ORDER BY EXAMID,HALLTICKET ";
        $studentsresult = $conn->query($getstudents);
        while ($student = mysqli_fetch_assoc($studentsresult)) {
           
            
         $floatingApplicable=isFloatationApplicable($student['HALLTICKET'],$student['EXAMID']);
         if($floatingApplicable==true) {
         

         echo "<tr>";
         echo "<hr>";
         echo "<h4 class='student-title'> HALLTICKET:  " . $student['HALLTICKET'] . "&nbsp;&nbsp;&nbsp;NAME: " . $student['sname'] . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  S/o&nbsp;D/o &nbsp;&nbsp;" . $student['fname'];
         echo '</h4>';
         echo "<hr></tr>";
        
        $getpapers = "SELECT RESULTS_STAGE.*,ALPHACODES.ALPHACODE from RESULTS_STAGE LEFT JOIN ALPHACODES ON `RESULTS_STAGE`.`PAPERCODE` =`ALPHACODES`.`NUMERICCODE` WHERE EXAMID=". $student['EXAMID'] . " and HALLTICKET='" . $student['HALLTICKET']. "' ORDER BY PAPERCODE";
         // echo $getpapers;
        $papers = $conn->query($getpapers);
        echo "<tr>";
        ?>
    <table >
    <tr>
        <td>
            PCODE<br>
            EXT:<br>
            INT:<br>
            TOT:<br>
            RES:SC
        </td>
    
    <?php foreach($papers as $paper):?>
        <!--<pre>-->
        <?php //echo implode($paper,"|"); ?>
        <!--</pre>-->
         <td style="padding-right:1em">
             <?=$paper['ALPHACODE']?>/<?=$paper['PAPERCODE']?><br>
             <?= $paper['EXT'] == "AB" ? "AB" : str_pad($paper['EXT'],3,"0", STR_PAD_LEFT); ?> /
             <?= $paper['ETOTAL'] == "AB" ? "AB" : str_pad($paper['ETOTAL'],3,"0", STR_PAD_LEFT); ?>
             <br>
             <?= $paper['INT'] == "AB"?"AB" : str_pad($paper['INT'],3,"0", STR_PAD_LEFT); ?> /
             <?= $paper['ITOTAL'] == "AB" ? "AB" : str_pad($paper['ITOTAL'],3,"0", STR_PAD_LEFT); ?>
            <br>
            <?=$paper=="AB"?"AB" : str_pad($paper['MARKS'],3,"0", STR_PAD_LEFT); ?>/
            <?=str_pad($paper['TOTALMARKS'],3,"0", STR_PAD_LEFT); ?>
            <br>
           <?=$paper['RESULT']?> ::
           <?=$paper['CODE']?>
         </td>

    <?php endforeach; ?>
    
    <?php 
    $result=consolidatedreport($papers);        
    ?>
    <td>
        <?php  echo $floatingApplicable; ?><BR>
        <?=$result['MARKS']?>/<?=$result['TOTAL']?><br>
        <?=round($result['PERCENTAGE'],2);?>%<br>
        
    </td>
    </tr>
    </table>



<?php
    
    echo "<tr>";
    }
        }
        // end of students
}
?>
    </tbody>
</table>
<div class="watermark">
    <img src="http://uascku.ac.in/kulogo.jpg" style="opacity:0.1">
</div>