<?php
error_reporting(E_ALL);
include "../config.php";
//check connection
if(isset($_GET['processid'])){
$processid=$_GET['processid']; 
}
else{
    $date = getdate();
    
    echo $processid= date_format($date, 'YmdHis');
    
}
$db=$_GET['db'];

echo $examid;
echo $processid;
echo $db;

$conn = mysqli_connect($servername, $dbuser, $dbpwd, "atech_ebms");

//check connection
if ($conn->connect_error){
    die("connection failed:".mysqli_connect_error());
}
else{
echo $getenrollmentids = "select DISTINCT(HALLTICKET) as HALLTICKET,EXAMID FROM RESULTS_STAGE";
echo $getenrollments;
$deleteenrollments="delete from GPAS_STAGE WHERE 1=1";
$deleted=$conn->query($deleteenrollments);
$enrollmentids = $conn->query($getenrollmentids);
if($enrollmentids->num_rows>0){
    $total=0;
    $credit_total=0;
    $gpc_total=0;
    while($row=mysqli_fetch_assoc($enrollmentids)){
       // print_r($row);
        echo $sql="select * from RESULTS_STAGE where HALLTICKET=".$row['HALLTICKET']." and EXAMID=".$row['EXAMID']." ";
        $studentres=$conn->query($sql);
       if($studentres->num_rows>0){
            echo "<hr><table border=1>";
                $result="P";
                $total=0;
                $credit_total=0;
                $gpc_total=0;
                        
                while($paper=mysqli_fetch_assoc($studentres)){
                    $hallticket=$row['HALLTICKET'];
                    //echo "HALLTICKET :".$hallticket;
                    echo "<tr>";
                    foreach($paper as $cell){
                        echo "<td>$cell</td>";
                        
                    }
                    echo "</tr>";
                    
                    $total=$total+$paper['MARKS'];
                    $credit_total=$credit_total+$paper["CREDITS"];
                    $gpc_total=$gpc_total+$paper["GPC"];
                    if($paper['RESULT']=="F" || $paper['RESULT']=="AB"){
                        $result="R";
                    
                    
                    }
                    
                }//end of fetching papers
                echo "GPC TOTAL".$gpc_total;
                echo "CREDITS TOTAL ".$credit_total."<hr>";
                
                echo $sgpa=$gpc_total/$credit_total;
                echo $sgpa=round($sgpa,2);
                echo $cgpa=$sgpa;
                 $query="INSERT INTO `GPAS_STAGE`(`GPAID`,`EXAMID`, `HALLTICKET`, `TOTAL`, `RESULT`, `SGPA`, `CGPA`, `PROCESSID`) values (NULL,". $row['EXAMID'] .",'$hallticket',$total,'$result','$sgpa','$cgpa','$processid')";
                echo "</table>";
                echo $query;
                if($conn->query($query)){
                    echo "<hr>Update Successfull<hr>";
                }
                
       }
        
    }
    }
}

?>
  