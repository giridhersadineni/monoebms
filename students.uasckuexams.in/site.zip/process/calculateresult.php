<?php
set_time_limit(1000);
ini_set('display_errors', 1);
include "../config.php";
$table=$_GET['t'];
function isAbsentInternal($paper){
    if($paper['INT']=="AB"){
    return true;
    }
    return false;
}

function isAbsentExternal($paper){
    if($paper['EXT']=="AB"){
        return true;
    }
    return false;
}

function isMalpractice($paper){
    if($paper['EXT']=="MP"){
        return true;
    }
    return false;
}

function isPracticalPaper($paper){
    if($paper['INT']==0 && $paper['ITOTAL']==0){
        return true;
    }
    return false;
}
function isTheoryPaper($paper){
    if( $paper['ETOTAL']!=0 && $paper['ITOTAL']!=0 ){
        return true;
    }
    return false;
}
function isPassedExternal($paper){
    if($paper['EXT']/$paper['ETOTAL']>=0.40){
        return true;
    }    
    return false;
}
function isPassedInternal($paper){
    if(isAbsentInternal($paper)){
        return false;
    }
    else if($paper['ITOTAL']==0 && $paper['INT']==0){
        return true;
    }
    else if($paper['INT']/$paper['ITOTAL']>=0.40){
        return true;
    }    
    return false;
}


function isPassedExternalOnly($paper){
    if(isAbsentExternal($paper)){
        return false;
    }
    else if($paper['EXT']/$paper['TOTALMARKS']>=0.40){
        return true;
    }
}
function isFailedInternal($paper){
    if($paper['INT']/$paper['ITOTAL']>=0.40){
        return true;
    }
}
function isFailedExternal($paper){
    if($paper['EXT']/$paper['ETOTAL']>=0.40){
        return true;
    }
}

function getResult($paper){
    if(isMalpractice($paper)){
        return "MP";
    }
    if(isPassedExternalOnly($paper)){
        return "P";
    }
    else if(isAbsentExternal($paper)){
        return "AB";
    }
    else if(isPassedExternal($paper) && isPassedInternal($paper)){
        return "P";
    }
    else if(isAbsentInternal($paper) && isPassedExternalOnly($paper)){
        return "p";
    }
    else{
        return "F";
    }

    
} 
// end of getResult

function calculateTotal($paper){
    $paper['TOTALMARKS'] = $paper['ITOTAL'] + $paper['ETOTAL'];
    
    if($paper['EXT']==='AB' &&  $paper['INT']!='AB')
    {
        $paper['MARKS']=$paper['INT'];
    }
    if($paper['EXT']==='AB' &&  $paper['INT']==='AB')
    {
        $paper['MARKS']=0;
    }
    
    if($paper['EXT']!='AB' &&  $paper['INT']=='AB')
    {
        $paper['MARKS'] = $paper['EXT'];
    }
    
    if($paper['EXT']!='AB' &&  $paper['INT']!='AB')
    {
        $paper['MARKS']=$paper['EXT']+$paper['INT'];
    }
    
    return $paper; 
}

function calculatePaperResult($paper){
    if($paper['EXT']==="AB" && $paper['INT']!="AB"){
        $paper['MARKS']=0;
    }
    if($paper['EXT']!="AB" && $paper['INT']!="AB"){
        $paper['MARKS'] = $paper['EXT'] + $paper['INT'];
    }
    if($paper['EXT']!="AB" && $paper['INT']==="AB"){
        $paper['MARKS']=$paper['INT'];
    }
    $paper=calculateTotal($paper);
    $paper['PERCENTAGE'] = round($paper['MARKS']/$paper['TOTALMARKS']*100,2);
    $paper['GPV']=round($paper['PERCENTAGE']/10,2);
    $paper['GPC']=$paper['CREDITS']*$paper['GPV'];
    $paper['GPCC']=$paper['GPC'];
    $paper['GPVV']=$paper['GPV'];
    $paper['GRADE']=getGrade($paper);
    $paper['RESULT']=getResult($paper);
  //  print_r($paper);
    return $paper;
}

function updatePaper($paper){
    global $servername,$dbuser,$dbpwd,$table;
    $conn = mysqli_connect($servername, $dbuser, $dbpwd, "atech_ebms");
    if ($conn->connect_error) {
        die("connection failed:" . mysqli_connect_error());
    } else {
    $query="update ".$table." set ";
    $query.= "RESULT='".$paper['RESULT']. "' ";
    $query.= ",`GRADE`='".$paper['GRADE']. "' ";
    $query.= ",MARKS=".$paper['MARKS']. " ";
    $query.= ",TOTALMARKS=".$paper['TOTALMARKS']. " ";
    $query.= ",GPC=".$paper['GPC']. " ";
    $query.= ",GPCC=".$paper['GPCC']. " ";
    $query.= ",GPV=".$paper['GPV']. " ";
    $query.= ",GPVV=".$paper['GPVV']. " ";
    $query.= ",PERCENTAGE=".$paper['PERCENTAGE']. " ";
    $query.= "WHERE RHID=".$paper['RHID']. " ";
    echo $query;
        $data=$conn->query($query);
        
    }
}



function getGrade($paper){

    if($paper['RESULT']=="AB") {
        return "AB";
    }
    else if($paper['RESULT']=='F'){
        return "F";
    }
    else if($paper['RESULT']=='MP'){
        return "MP";
    }
    else if($paper['RESULT']=="P")
    {
        $percentage=$paper['PERCENTAGE'];
        if($percentage>=85 ){
            return "O";
        }
        else if($percentage>=70){
            return "A";
        }
        else if($percentage>=60){
            return "B";
        }
        else if($percentage>=55){
            return "C";
        }
        else if($percentage>=50){
            return "D";
        }
        else if($percentage>=40){
            return "E";
        }
        else{
            return "F";
        }
    }
    
}


$conn = mysqli_connect($servername, $dbuser, $dbpwd, "atech_ebms");
if ($conn->connect_error) {
    die("connection failed:" . mysqli_connect_error());
} else {
$getdata="select * from ".$table;
$data=$conn->query($getdata);
    while( $paper = $data->fetch_assoc() )
    {
        echo implode($paper," "); echo "<br>";
        $paper=calculatePaperResult($paper);
        echo "<pre>";
        print_r($paper);
        echo "</pre>";
        updatePaper($paper);
        echo $paper['RHID']."<br>";
        //break;
    }
}








?>
    