<?php include "header.php";
include "projectorm.php";
?>


<?php

include 'config.php';

if (isset($_POST['submit'])) {
 
    $hallticket=$_POST["hall_ticket_no"];
    $p1cgpa=$_POST["P1CGPA"];
    $p2cgpa =$_POST["P2CGPA"];
    $allcgpa =$_POST["ALLCGPA"];
    $p1cf =$_POST["P1CF"];
    $p2cf =$_POST["P2CF"];
    $allcf =$_POST["ALLCF"];
    $p1div =$_POST["P1DIV"];
    $p2div =$_POST["P2DIV"];
    $finaldiv =$_POST["FINALDIV"];
    $p1subs =$_POST["P1SUBS"];
    $p2subs =$_POST["P2SUBS"];
    $p2sub1 =$_POST["P2SUB1"];
    $p2sub2 =$_POST["P2SUB2"];
    $p2sub3 =$_POST["P2SUB3"];
    
    

    $conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);

    if (!$conn) {
        die("connection failed:" . mysqli_connect_error());
    }
 
    
    $sql= 'UPDATE  dev_grades SET P1CGPA="'.$p1cgpa.'",P2CGPA="'.$p2cgpa.'",ALLCGPA="'.$allcgpa.'",P1CF="'.$p1cf.'",P2CF="'.$p2cf.'",
    
    ALLCF="'.$allcf.'",`P1DIV`="'.$p1div.'",P2DIV="'.$p2div.'",FINALDIV="'.$finaldiv.'",P1SUBS="'.$p1subs.'", P2SUBS='.$p2subs.',
    
    P2SUB1="'.$p2sub1.'",P2SUB2="'.$p2sub2.'",P2SUB3="'.$p2sub3.'"  WHERE HALLTICKET ='.$hallticket;

    
    
     //print_r($sql);
    if ($conn->query($sql) === true) {
        //return print_r($conn);
        header("Location:grades.php?message=Provisional added");
        
    } else {
        if($conn->errno==1062){
            header('Location:'.$SERVER['HTTP_REFERRER'].'?error=duplicate');
        }
        else{
        echo $sql;
        }
    }

    $conn->close();

}

?>

<div class="page-wrapper p-3">
    <div class="row mx-3">
        <p class="text-right">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#provisionalform">
        Provisional Form</button>
    </p>
  
        <div class="col mx-3">
        <p class="text">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#genarateCMM">
        Generate CMM</button>
    </p>
    </div>
      </div>
    <div class="row card">
           
        <div class="col-12 p-2">
            <?php
            $query="select * from grades left join students on grades.HALLTICKET=students.haltckt";
            // echo $query;
            getdatatable($query,"display table table-hover table-striped table-bordered wrap table-responsive", "example23", "PrintCMM","Provisional");
            ?>
            
        </div>
    </div>
</div>


<script>
    
    function PrintCMM(id){
        // alert("clicked view");
        url="printcmm.php?id="+id;
        console.log(id);
        window.open(url,"_BLANK");
        console.log(url);
    }
        
    function Provisional(id){
        // alert("clicked view");
        url="printprovisional.php?id="+id;
        console.log(id);
        window.open(url,"_BLANK");
        console.log(url);
    }
    
</script>






<!-- Modal -->
<div class="modal fade" id="provisionalform" tabindex="-1" role="dialog" aria-labelledby="provisionalform" aria-hidden="true">
  <div class=" modal-dialog modal-lg"  role="document">
   
<div class="modal-content" >
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Provisional Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
<form action="grades.php" method="POST" >
<div class="modal-body" >
<div class="container">  
<div class="row" style="background-color:red;" >
     <div class="col">
        <label for="" style="color:white;">HALLTICKET NO:</label>
        <input type="text" class="form-control" placeholder="Enter Hallticket Number " name="hall_ticket_no" id="hall_ticket_no">
        <label></label>
     </div>
     </div>
<br>
    <div class="row">
     <div class="col">
        <label for="">PART-1-CGPA</label>
        <input type="text" class="form-control" placeholder="P1CGPA" name="P1CGPA" >
     </div>
        <div class="col">
            <label for="">PART-2-CGPA</label>
          <input type="text" class="form-control" placeholder="P2CGPA" name="P2CGPA" >
        </div>
          <div class="col">
            <label for="">ALLCGPA</label>
            <input type="text" class="form-control" placeholder="ALLCGPA" name="ALLCGPA">
          </div>
    </div>
      <br>

      <div class="row">
        <div class="col">
            <label for="">PART1-CORRECTION-FACTOR</label>
          <input type="text" class="form-control" placeholder="P1CF" name="P1CF" >
        </div>
        <div class="col">
            <label for="">PART2-CORRECTION-FACTOR</label>
          <input type="text" class="form-control" placeholder="P2CF" name="P2CF">
        </div>
        <div class="col">
            <label for="">ALLCORRECTION-FACTOR</label>
            <input type="text" class="form-control" placeholder="ALLCF" name="ALLCF">
          </div>
      </div>
      <br>

      <div class="row">
        <div class="col">
            <label for="">PART1-DIVISION</label>
          <input type="text" class="form-control" placeholder="P1DIV" name="P1DIV" >
        </div>
        <div class="col">
            <label for=""> PART-2-DIVISON</label>
          <input type="text" class="form-control" placeholder="P2DIV" name="P2DIV" >
        </div>
        <div class="col">
            <label for="">FINAL-DIVISON</label>
            <input type="text" class="form-control" placeholder="FINALDIV" name="FINALDIV" >
          </div>
      </div>
<br>
      <div class="row">
        <div class="col-sm-4">
            <label for="">PART1-SUBJECTS </label>
          <input type="text" class="form-control" placeholder="P1SUBS" name="P1SUBS">
        </div>
        <div class="col-sm-4">
            <label for="">PART2-SUBBJECTS</label>
          <input type="text" class="form-control" placeholder="P2SUBS" name="P2SUBS" >
        </div>
            <div class="col-sm-4">
            <label for="">PART2-SUBBJECT1</label>
          <input type="text" class="form-control" placeholder="P2SUB1" name="P2SUB1" >
        </div>
            <div class="col-sm-4">
            <label for="">PART2-SUBBJECT2</label>
          <input type="text" class="form-control" placeholder="P2SUBS2" name="P2SUBS2" >
        </div>
               <div class="col-sm-4">
            <label for="">PART2-SUBBJECT3</label>
          <input type="text" class="form-control" placeholder="P2SUBS3" name="P2SUBS3" >
        </div>
        
      </div>

      <div class="modal-footer">
          <input type="submit" class="btn btn-primary" name="submit" value="Update data">
 
        </div>
</div>
</div>
        </form>
        
      </div>
    </div>
  </div>
</div>


<?php if(isset($_GET['message'])): ?>



<?php endif;?>





<?php include "datatablefooter.php";?>