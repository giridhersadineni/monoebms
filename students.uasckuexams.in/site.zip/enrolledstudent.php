<?php
/*
session_start();
if(!(isset($_SESSION['login'])))
{
header("location:index.php?sessionexpired");
}
 */
?>

<?php include "header.php";?>
<?php
include "config.php";
//check connection

$conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);
//check connection
if ($conn->connect_error) {
    die("connection failed:" . mysqli_connect_error());
} else {
    $sql = "select * from enrolledview where id=" . $_GET['id'];
    $result = $conn->query($sql);
    echo "  " . $result->num_rows;

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            break;
        }
    }
}
?>

<style>
.table,th,td{
 padding: 2px;   
  background-color: #f1f1c1;

  
}

.button
{
    background-color:#008CBA;
    color:white
}
h3
{

}
.img1{
    align:right;
    position:relative;
    top:240px;
    padding-right:5cm;
}

</style>
 <div class="page-wrapper">
            <!-- Bread crumb -->
<div class="row page-titles">
<div class="col-md-5 align-self-center">
<h3 class="text-primary">Student Details</h3>
</div>
<div class="col-md-7 align-self-center">
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="javascript:void(0)">View Student</a></li>
<li class="breadcrumb-item active">Student Details</li>
</ol>
</div>
</div>
<!-- End Bread crumb -->
<!-- Container fluid  -->
<!--<div class="container-fluid">-->
<!--<div class="row">-->
<!--<div class="col-md-12  toppad  pull-right col-md-offset-6 ">-->
<!--<div class="panel panel-info">-->
<!--<div class="panel-body">-->
<!--<div class="row">-->


<!-- Container fluid  -->
<div class="container">
<div class="row">
<div class="col-md-12  toppad  pull-right col-md-offset-6 ">
<div class="row">
<!--button-->

<div class="container">
<!-- The Modal -->
 <div class="card-body">
<div class='card'>
   
<div class="row justify-content-center">
<div class=" col-md-9 col-lg-9 ">

    
<div class="img1" align="right">
<img src="../students/upload/images/<?php echo $row['aadhar']; ?>.jpg" alt="profile pic" width="100px"/><br>
<img src="../students/upload/signatures/<?php echo $row['aadhar']; ?>.jpg" alt="signature" width="100px"/>
</div>


<table width="50%" >
<br>

<tbody>
<h4>1.Candidate details</h4>
<tr>
<td>Full Name:</td>
<td><center><strong><?php echo $row["sname"] ?></strong></center></td>
</tr>
<tr>
<td>Father Name:</td>
<td><center><strong><?php echo $row["fname"] ?></strong></center></td>
</tr>
<tr>
<td>Mother Name:</td>
<td><center><strong><?php echo $row["mname"] ?></strong></center></td>
</tr>

<tr>
<td>Email:</td>
<td><center><strong><?php echo $row["email"] ?></strong></center></td>
</tr>

<tr>
<td>Date of Birth:</td>
<td><center><strong><?php echo $row["dob"] ?></strong></center></td>
</tr>

<tr>
<td>Gender:</td>
<td><center><strong><?php echo $row["gender"] ?></strong></center></td>
</tr>

<tr>
<td>Phone Number:</td>
<td><center><strong><?php echo $row["phone"] ?></strong></center></td>
</tr>
</tbody>
</table>
<table width="50%">
<tbody>
<br>

<h4>2.Course details</h4>
<tr>
<td>Group:</td>
<td><center><strong><?php echo $row["group"] ?></strong></center></td>
</tr>

<tr>
<td>Halltickt:</td>
<td><center><strong><?php echo $row["haltckt"] ?></strong></center></td>
</tr>

<tr>
<td>Semester:</td>
<td><center><strong><?php echo $row["sem"] ?></strong></center></td>
</tr>

<tr>
<td>Year:</td>
<td><center><strong><?php echo $row["curryear"] ?></strong></center></td>
</tr>

<tr>
<td>Aadhar:</td>
<td><center><strong><?php echo $row["aadhar"] ?></strong></center></td>
</tr>
</tbody>
</table>
<br>

<table width="50%">

<tbody>
<h4>3.Address of Candidate</h4>
<tr>
<td>Address:</td>
<td><center><strong><?php echo $row["address"] ?></strong></center></td>
</tr>
<tr>
<td>Manadal:</td>
<td><center><strong><?php echo $row["mandal"] ?></strong></center></td>
</tr>
<tr>
<td>City:</td>
<td><center><strong><?php echo $row["city"] ?></strong></center></td>
</tr>
<tr>
<td>State:</td>
<td><center><strong><?php echo $row["state"] ?></strong></center></td>
</tr>
<tr>
<td>Pincode :</td>
<td><center><strong><?php echo $row["pincode"] ?></strong></center></td>
</tr>

</tbody>
</table>
<br>

<table width="50%" style="">

<tbody>
<h4>3. Selected Subjects </h4>
<tr>
<td>Subject1:<strong><?php echo $row["S1"] ?></strong></td>
<td>Subject2:<strong><?php echo $row["S2"] ?></strong></td>
</tr>
<tr>
<td>Subject3:<strong><?php echo $row["S3"] ?></strong></td>
<td>Subject4:<strong><?php echo $row["S4"] ?></strong></td>
</tr>

<tr>
<td>Subject4:<strong><?php echo $row["S4"] ?></strong></td>
<td>Subject5:<strong><?php echo $row["S5"] ?></strong></td>
</tr>

<tr>
<td>Subject6:<strong><?php echo $row["S6"] ?></strong></td>
<td>Subject7:<strong><?php echo $row["S7"] ?></strong></td>
</tr>

<tr>
<td>Subject8:<strong><?php echo $row["S8"] ?></strong></td>
<td>Subject9:<strong><?php echo $row["S9"] ?></strong></td>
</tr>
<tr>
<td>Subject10:<strong><?php echo $row["S10"] ?></strong></td>
<td>Elective1:<strong><?php echo $row["E1"] ?></strong></td>
</tr>

<tr>
<td>Elective2:<strong><?php echo $row["E2"] ?></strong></td>
<td>Elective3:<strong><?php echo $row["E3"] ?></strong></td>
</tr>


<tr>
<td>Elective4:<strong><?php echo $row["E4"] ?></strong></td>
<td></td>
</tr>
</tbody>
</table>
<br>
<table width="60%">
<tbody>
<h4>4.Fee Details:</h4>
<tr>
<td>Fee Amount:<strong><?php echo $row["FEEAMOUNT"] ?></strong></td>
<td>Challan Submited On:<strong><?php echo $row["CHALLANSUBMITTEDON"] ?></strong></td>
</tr>

</tbody>
</table>
<br>
<br>
<p align="center"> <a href="printenrolled.php?id=<?php echo $row["ID"]; ?>" class="btn btn-primary" target="_blank">Print Student Details</a>
<p align="center"><a class="btn btn-success" href="enrolledview.php" >Back</a></p>
</div>
</div>
</div>
</div>
</div>
</div>

<!--end of page content-->
<?php include "datatablefooter.php";?>