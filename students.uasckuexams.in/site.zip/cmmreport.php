<?php include 'header.php'?>
<div class="page-wrapper bg-white">
    <div class="row">
    <div class="col-md-12">
    <div class='card'>
 <center>
    <div class="row">
        <div class="col-6">
            <form action="cmmreport.php" method="POST">
            <div class="input-group p-1 bg-warning">
                <input type="text"  name="HALLTICKET" placeholder="Hallticket" class="form-control input-prepend">
                <input type="submit" name="submit" value="View Report" class="btn btn-success input-apppend"></input>
            </div>
            </form>
        </div>
        <div class="col-6">
            <a  href="printcmm.php?hallticket=<?php echo $_POST['ht']?>"  class="btn btn-primary">PRINT MEMO</a>
        </div>
    </div>
</center>
       
    <div class="table-responsive m-t-40">
        
<?php
include "config.php";
//check connection
$conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);
//check connection
if ($conn->connect_error){
    die("connection failed:".mysqli_connect_error());
}
else{
    
         $getresult="select * from RESULTS where HALLTICKET='".$_POST['HALLTICKET']."' ORDER BY PAPERCODE";
        //  echo $getresult;
         echo '<table id="example23" class="display nowrap table table-hover
         table-striped table-bordered" cellspacing="0" width="100%">';
         $enrolledexams=[];
         $subs=$conn->query($getresult);
         
         
 ?>

<thead>
<tr>
    <th>RHID</th>
    <th>EXAMID</th>
    <th>PAPERCODE</th>
    <th>PAPERNAME</th>
    <th>PART</th>
    <th>HALLTICKET</th>
    <th>EID</th>
    <th>CODE</th>
    <th>EXT</th>
    <th>ETOTAL</th>
    <th>INT</th>
    <th>ITOTAL</th>
    <th>CREDITS</th>
    <th>RESULT</th>
    <th>MARKS</th>
    <th>TOTALMARKS</th>
    <th>PERCENTAGE</th>
    <th>GRADE</th>
    <th>GPC</th>
    <th>GPV</th>
    <th>UPLOADID</th>
    <th>SEM</th>
    <th>MYEAR</th>
    <th>GPCC</th>
    <th>GPVV</th>
    <th>MARKER</th>
    <th>ATTEMPTS</th>
    <TH>STATUS</TH>
    
</tr>
</thead>
<tbody>
<?php
while($paper=mysqli_fetch_assoc($subs)){
            echo "<tr>"; 
            // echo '<td><a  href="editmarks.php?id='. $paper["RHID"]. '&hallticket='. $_POST['ht'].'" class="btn btn-warning"><i class="fa fa-user-edit"></i></a></td>';
            
            foreach($paper as $col){
                echo "<td>".$col."</td>";
                }
            echo "</tr>";
         }

    }
    
    ?>
     


<?php
mysqli_close($conn);
?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>

<?php include 'datatablefooter.php'?>
