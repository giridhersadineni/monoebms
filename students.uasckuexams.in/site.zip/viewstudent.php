<?php include "header.php";?>
<?php
include "config.php";
//check connection


$conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);
//check connection
if ($conn->connect_error) {
    die("connection failed:" . mysqli_connect_error());
} else {
    $sql = "select * from students where haltckt=" . $_POST['hallticket'];
    // $sql = "select * from students where haltckt='001172022'";
    $result = $conn->query($sql);
    echo "  " . $result->num_rows;

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            break;
        }
    }
}
?>

<?php
include "config.php";
//check connection

$conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);
if ($conn->connect_error) {
    die("connection failed:" . mysqli_connect_error());
} else {
    $sql = "select * from  enrolledview where stid='" . $row['stid'] . "'";
    $result = $conn->query($sql);

}
?>


<div class="page-wrapper">

 <!--Container fluid  -->
<div class="container-fluid">
<div class='card'>
    
    
<div class="row">
<div class="col-md-12">
<h3 class="box-title  ">
Student Details <span class="pull-right">	


<div class="row">
<div class="btn-group pull-right">
<form action="https://uascku.ac.in/ebms/students/index.php" method="POST">
    <input type="hidden" value="<?=$row['haltckt'];?>" name="haltckt">
    <input type="hidden" value="<?=$row['dob'];?>" name="dob">
    <input type="submit" name="submit" value="Login" class="btn btn-success"></input>
</form>

    <a class="btn btn-danger" type="button"  href="editstudent.php?stid=<?php echo $row["stid"]?>" >Edit Record</a>
</div>
</div>
</h3>
</span>
</div>
</div>
 <!--Row Start here -->
<div class="row m-t-40">

<div class=" col-sm-2 col-lg-2 col-xs-2 ">
<img src="http://uascku.ac.in/ebms/students/upload/images/<?php echo $row['aadhar']; ?>.jpg" class="img-circle" alt="12345" width="100px"/><br>
<img src="http://uascku.ac.in/ebms/students/upload/signatures/<?php echo $row['aadhar']; ?>.jpg" class="img-circle" alt="12345" width="100px"/>
</div>

<div class="col-lg-10 col-sm-10 col-xs-12">
<div class="row ">
<div class="col-md-6 col-xs-12 ">
    
    <strong>Hallticket:</strong><?=$row["haltckt"]?><br>
    <strong>Student Name:</strong> <?=$row["sname"]?><br>
    <strong>Father Name:</strong> <?=$row["fname"]?><br>
    <strong>Mother Name</strong> <?=$row["mname"]?><br>
    <strong>Date of Birth</strong> <?=$row["dob"]?><br>
    <strong>Gender</strong> <?=$row["gender"]?><br>
    <strong>AADHAR</strong> <?=$row["aadhar"]?><br>
    <strong>Student ID:</strong><?=$row["stid"]?><br>
    
</div>
<div class="col-md-6 col-xs-12 ">
    <strong>Course</strong><?=$row["course"]?><br>
    <strong>Group</strong> <?=$row["specialization"]?><br>
    <strong>Medium</strong> <?=$row["medium"]?><br>
    <strong>Studying Year</strong> <?=$row["curryear"]?><br>
    <strong>Address</strong>:<?php echo $row["address"] ?> <br>
    <?php echo $row["address2"]?> <br>
    <?php echo $row["mandal"];?>&nbsp;<?php echo $row["city"]?> <br>
    <?php echo $row["state"]?>
    PinCode:<?php echo $row["pincode"]?></h5>
</div>



</div>
 <!--End here -->
</div>
  <!--End Card-->
</div>
<div>
<p class="text-left"><span class="text-large">Contact</span>
<a href="tel:<?=$row["phone"]?>" class="btn btn-primary btn-sm mb-1"> Call: <?=$row["phone"]?></a>
<a href="mailto:<?=$row["email"]?>" class="btn btn-primary btn-sm mb-1"> Email :<?=$row["email"]?></a>
</p>
</div>





</div>
<div class="card">
    <div class="row">
        <div class="col-12">
            <form action="cmmreport.php" method="POST">
            <input type="hidden" value="<?=$row['haltckt'];?>" name="HALLTICKET">
            <input type="submit" name="submit" value="Consolidated Marks" class="btn btn-success"></input>
        </form>
        </div>
    </div>
<div class="table-responsive m-t-40">
    
    
<table id="example23" class="display nowrxap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
<thead>
<tr>
    <th>ID</th>
    <th>Exam Id</th>
    <th>Exam Name</th>
    <th>Semester</th>
    <th>Exam Type</th>
    <th>Date of Enrollment</th>
    <th>Actions</th>
</tr>
</thead>
<tbody>
    <?php if ($result->num_rows > 0): ?>
    
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
         <tr>
             
         <td><?=$row["ID"]?></td>
         <td><?=$row["EXAMID"]?></td>
         <td><?=$row["EXAMNAME"]?></td>
         <td><?=$row["SEMESTER"]?></td>
         <td><?=$row["EXAMTYPE"]?></td>
         <td><?=$row["ENROLLEDDATE"]?></td>
         <td>
             <?php if($row['STATUS']=='RUNNING' || $row['STATUS']=='NOTIFY'): ?>
            
             <a href="editenrolled.php?id=<?=$row['ID']?>" class="btn btn-sm btn-info"> View Subjects Enrolled </a>
             <?php endif; ?>
             
            <form method='POST' action='mainresultall.php'>
            <input type="hidden" value='<?=$row["EXAMID"]?>' name="examid"></input>
            <input type="hidden" value='<?=$row["haltckt"]?>' name="hallticket"></input>
            <input type="hidden" value='<?=$row["ID"]?>' name="enrollmentid"></input>
            <input type="hidden" value='<?=$row["stid"]?>' name="studentid"></input>
            <input type="hidden" value='<?=$row["EXAMTYPE"]?>' name="examtype"></input>
            <input type="hidden" value='<?=$row["SEMESTER"]?>' name="SEM"></input>
            <button type='submit' class='btn btn-primary btn-sm'>View Result <?=$row['EXAMID']?></button>
            </form>
         </td>
         </tr>
        <?php endwhile ?>
    
    <?php else: ?>
    
    <tr><td colspan="5"> No Enrollments Found  !!! </td></tr>
    
    <?php endif ?>
    
    
    
</tbody>

   
     

<?php
mysqli_close($conn);
?>
</table>
</div>
      </div>
    </div>
  </div>
</div>



<!--End Contanier-->
</div>
 <!--End Page Wrapper -->

</div>

<?php include "footer.php";?>


