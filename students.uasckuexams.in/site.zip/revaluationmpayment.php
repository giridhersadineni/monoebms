<?php include 'header.php';?>

<?php
include 'config.php';
$id="";
$sname= "";
$course="";
$FEEAMOUNT="";
$EXAMNAME="";

if (isset($_GET['getdetails'])) {
  $ID=$_GET['ID'];
  $conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);
$query="SELECT  ID,HALLTICKET,FEEAMOUNT,FEEPAID FROM revaluationenrollments WHERE ID=".$ID;
$result=mysqli_query($conn,$query);

if($result->num_rows>0){
  while($row=mysqli_fetch_array($result))
  {
     $id=$row["ID"]; 
    $HALLTICKET=$row["HALLTICKET"];
    $FEEAMOUNT=$row['FEEAMOUNT'];
    $FEEPAID=$row['FEEPAID'];
    $EXAMNAME=$row['EXAMNAME'];
   
  }
  mysqli_close($conn);
}

else
{   
   $id="";
    $sname= "";
   
    $FEEAMOUNT="";
    $FEEPAID="";
    $EXAMTYPE=$row['EXAMTYPE'];

    echo "<script>alert('Details Not Found');</script>";
    mysqli_close($conn);
}
}
?>

<?php 
if(isset($_POST['update'])){
  $conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);
  if (!$conn) {
    die("connection failed:" . mysqli_connect_error());
  }
  $sql='UPDATE revaluationenrollments SET FEEPAID="'.$_POST['feepaid'].'",CHALLANRECBY="'.$_POST['challanrecd'].'",  CHALLANNUMBER="'.$_POST['CHALLANNUMBER'].'", CHALLANSUBMITTEDON="'.$_POST['CHALLANSUBDATE'].'" WHERE ID=' . $_POST['enrollid'];
  
 $currentDateTime = date('Y-m-d H:i:s');
 
  if ($conn->query($sql) === TRUE) {
      echo " <h2 class='text-success'>Payment Marked</h2>";
       echo "<h2 class='text-primary'> $currentDateTime</h2>";
  } 
  else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();

}
else{

}
?>
<div class="page-wrapper">
<!-- Container fluid  -->
<div class="container-fluid">
<!-- Start Page Content -->
<div class="row">
<div class="col-lg-12">
<div class="card card-outline-primary">        
<div class="card-body">
<div class="basic-form">
<style>
.img1{
 float:right;
 margin-right:10%;
}
</style>
<form action="revaluationmpayment.php" method="GET">
<div class="col-md-6">
<div class="input-group mb-3">
<input type="text" class="form-control" name="ID"  placeholder="Enter Registration Number">
  <div class="input-group-append">
    <input class="btn btn-warning" type="submit" name="getdetails" id="getdetails" value="Get Details">
  </div>
  </div>
</div>
</form>
<?php
include 'config.php';
$conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);
$name="SELECT * FROM students WHERE haltckt=".$HALLTICKET;
//echo $name;
 $result = $conn->query($name);
    if ($result->num_rows > 0) {
        while($rows= $result->fetch_assoc()){
            break; 
        }
}

?>
<input type="hidden" name="id" value="<?php echo $id;?>">

<div class="img1">
<img src="../students/upload/images/<?php echo $rows['aadhar'];?>.jpg" alt="12345" width="100px"/><br>
<img src="../students/upload/signatures/<?php echo $rows['aadhar'];?>.jpg"  alt="12345" width="100px"/>

</div>
<form action="revaluationmpayment.php" method="POST">
<table width="60%" border="1px solid">
<input type="hidden" name="id" value="<?php echo $id;?>">

<tbody>
<h4>1.Candidate details</h4>
<tr>
<td>Student Name:</td>
<td><center><h3><?php echo $rows['sname'] ?></h3></center></td>
</tr>
<br>
<tr>
<td>Course:</td>
<td><center><h3><?php echo $rows['course']?></h3></center></td>
</tr>

<tr>
<td>Fee Amount:</td>
<td><center><h3><?php echo $FEEAMOUNT; ?></h3></center></td>
</tr>
<tr>
<td>Fee Paid:</td>
<td><center><h3><?php if ($FEEPAID==1){
echo '<h4 class="text-success"> FEE PAID </h4>';
}else{
echo '<h4 class="text-danger"> NOT PAID </h4>';
}
?></h3></center></td>
</tr>

</form>

<form action="revaluationmpayment.php" method="POST">
 
<tr>
<td>Challan Number:</td>
<td><input type="text" class="form-control" placeholder="Enter Challan Number" value="<?php $row['CHALLANNUMBER'] ?>" name="CHALLANNUMBER" ></td>
</tr>

<input type="hidden" name="enrollid" value="<?php echo $id;?>">
<tr>
<td>Challan Date:</td>
<td><input type="" class="form-control" placeholder="" name="CHALLANSUBDATE" value="<?php echo  DATE("d/m/Y")?>"></td>
</tr>
<tr>
<td><h4>Fee Paid:<h4></td>

<td class="text-danger">


    <center>
    <input type="checkbox" name="feepaid" value="1"><strong>TICK TO THIS UPDATE FEE </strong>
    </center>
    
    
    </td>

</tr>
<input type="hidden" name="challanrecd" value="<?php echo $_COOKIE['userid']; ?>">  
</tbody>
</table>
<br>
<p align="center"><input type="submit" class="btn btn-primary" name="update" value="Mark Payment"></p>

</form>

</div>
</div>
</div>
</div>
</div>
</div>
<?php include 'datatablefooter.php'?>
