<?php include "header.php";
function spitrow($row){
    $record="";
    foreach($row as $column=>$value){
        $record=$record."<td>".$column."</td>";
    }
    return $record;
}
function get_row_fields($row,$columns){
    $record="";
    $arr=array_values($columns);
    foreach($arr as $column){
        $record=$record."<td>".$row[$column]."</td>";
    }
    return $record;
}


?>




<?php
include "config.php";
//check connection
$conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);

if ($conn->connect_error) {
    die("connection failed:" . mysqli_connect_error());
} else {
    $sql = "SELECT * FROM `revaluationenrollments` WHERE FEEPAID=1";
    $result = $conn->query($sql);
    
  
}
?>


<!-- End Left Sidebar  -->

<!-- Page wrapper  -->
<div class="page-wrapper">
<!-- Bread crumb -->

<div class="row page-titles">
 <div class="col-md-5 align-self-center">
 <!--<h3 class="text-primary">Dashboard</h3> -->
 </div>

 <div class="col-md-7 align-self-center">
 <ol class="breadcrumb">
 <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
 <li class="breadcrumb-item active">Enrolled Details</li>
 </ol>
 </div>
 </div>
 <!-- End Bread crumb -->

<!-- Container fluid  -->
<div class="container-fluid">
<!-- Start Page Content -->
<div class="row">
<div class="col-12">
<div class="card">
<div class="card-body">
<div class="table-responsive m-t-40">
<table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">

            <!--<thead>-->
            <!--                       <tr>-->
            <!--                  <th>Id</th>-->
            <!--                  <th>Student name</th>-->
            <!--                  <th>Phone</th>-->
            <!--                  <th>Sub1<th>-->
            <!--                  <th>Sub2</th>-->
            <!--                  <th>Sub3</th>-->
            <!--                  <th>Sub4</th>-->
            <!--                  <th>Sub5</th>-->
            <!--                  <th>Sub6</th>-->
            <!--                  <th>Sub7</th>-->
            <!--                  <th>Sub8</th>-->
            <!--                  <th>Sub9</th>-->
            <!--                  <th>E1</th>-->
            <!--                  <th>E2</th>-->
            <!--                  <th>E3</th>-->
            <!--                  <th>E4</th>-->
                            
            <!--                  <th>Fee Amount</th>-->
            <!--                  <th>Challan Submited On</th>    -->
                              <!-- <th>View</th> -->

            <!--                  </tr>-->
            <!--     </thead>-->
        <?php
        $columns=['RHID','EXAMID','HALLTICKET','PAPERCODE','PAPERNAME','CODE','EID','EXT','ETOTAL','INT','ITOTAL','RESULT','GRADE'];
        echo "<thead><tr><th>Action</th><th>APP_ID</th>";
        foreach($columns as $heading){
            echo "<th>".$heading."</th>";
        }
        echo "</tr></thead>";
        ?>   
<?php
if ($result->num_rows > 0) {
    // output data of each row
    
    while($enrollment=mysqli_fetch_assoc($result)){
       $examid=$enrollment['EXAMID'];
       $hallticket=$enrollment['HALLTICKET'];
       $enrollmentid=$enrollment['ID'];
       
        
        $subs=array_slice($enrollment,4,14);
        //echo '<table class="table table-striped">';
        $columns=['RHID','EXAMID','HALLTICKET','PAPERCODE','PAPERNAME','CODE','EID','EXT','ETOTAL','INT','ITOTAL','RESULT','GRADE'];
        // echo "<tr><th>Action</th><APP_ID>";
        // foreach($columns as $heading){
        //     echo "<th>".$heading."</th>";
        // }
        // echo "</tr>";
        // echo "</thead><tbody>";
        foreach($subs as $subject){
               
            if($subject!='null' and $subject!=""){
                $getsubresult="select * from RESULTS where EXAMID=$examid and HALLTICKET=$hallticket and PAPERCODE='".$subject."'";
                $res=$conn->query($getsubresult);
                $sub_result=mysqli_fetch_assoc($res);
                echo "<tr><td></td>";
                //  echo "<td><a href='editcmmreport.php?hallticket=$hallticket&id=".$sub_result['RHID']."' class='btn btn-primary'><i class='fas fa-pen'></i></a></td>";
                echo "<td>$enrollmentid</td>".get_row_fields($sub_result,$columns)."</tr>";
                
            }
        }
        //echo "</tbody></table>";
        
    }
    
    // TRYOUT CODE
    // $records=$result->fetch_all(MYSQLI_BOTH);
    // echo '<pre>';
    // print_r($records);
    // echo '</pre>';
    
} else {
    echo '<tr><td colspan="5">No Branches - Empty Table</td></tr>';
}
?>

<?php
mysqli_close($conn);
?>

</table>
</div>
</div>
</div>
</div>
</div>
<!-- footer -->
<?php include "datatablefooter.php";?>