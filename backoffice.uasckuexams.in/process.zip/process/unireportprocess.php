<?php 


    header('Content-type: text/csv');
    header("Content-Disposition: attachment; filename=report.csv"); 
    header("Content-Transfer-Encoding: binary");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Cache-Control: private",true);
    
    echo "ID,MEMO_NO,HALLTICKET,S1GPA,S2GPA,S3GPA,S4GPA,S5GPA,S6GPA,P1YOP,P2YOP,ALLYOP,ADMYEAR,REMARKS,P1CGPA,P2CGPA,ALLCGPA,P1CF,P2CF,ALLCF,P1DIV,P2DIV,FINALDIV";
    echo "\n";


    set_time_limit(600);
    include 'config.php';
    $conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);

    function calcsgpa($papers){
                $credit_total=0;
                $gpc_total=0;
                foreach($papers as $paper){
                   
                    $gpc_total+=$paper['GPC'];
                    $credit_total+=$paper['CREDITS'];
                }
                
                $gpa=$gpc_total/$credit_total;
               
                return $gpa;
                
    }
            
    function get_division($gpa){
                $percentage=($gpa*10)-$cf;
                if($percentage>=75){
                    return "FIRST DIVISION WITH DISTINCTION";
                }
                else if($percentage>=60){
                    return "FIRST DIVISION";
                }
                else if($percentage>=55)
                {
                    return "SECOND DIVISION";
                }
                else
                {
                    return "THIRD DIVISION";
                }
                
                //return $percentage;
    }
            
    function consolidatereport($papers){
                $marks_sec=0;
                $totalmarks=0;
                $credit_total=0;
                $gpc_total=0;
                $gpcc_total=0;
                $percentages=array();
                $cgpa_percentages=array();
                foreach($papers as $paper){
                    $gpc_total+=$paper['GPC'];
                    $credit_total+=$paper['CREDITS'];
                    $marks_sec+=$paper['MARKS'];
                    $totalmarks+=$paper['TOTALMARKS'];
                    $gpcc_total+=$paper['GPCC'];
                }
                $result=array();
                $result['marks']=$marks_sec;
                $result['total']=$totalmarks;
                $result['gpc_total']=$gpc_total;
                $result['credits']=$credit_total;
                $result['cgpa']=$gpc_total/$credit_total;
                $result['OGPA']=$gpcc_total/$credit_total;
                $per=$marks_sec/$totalmarks*100;
                $cper=$result['OGPA']*10;
                $result['CF']=$per-$cper;
                $result['PERCENTAGE']=$per;
                $result['DIVISION']=get_division($result['cgpa']);
                return $result; 
    }
            
    function getsempapers($hallticket,$semester){
                global $conn;
                $query = "select * from  rholdernew where  RESULT NOT IN('F','AB') AND HALLTICKET='$hallticket' AND PAPERCODE LIKE '$semester%' ORDER BY PAPERCODE";
                // echo $query;
                $queryresult=$conn->query($query);
                $papers=array();
                //print_r($papers);
                while($sub=mysqli_fetch_assoc($queryresult)){
                    array_push($papers,$sub);
                };
                return $papers;
    }
    
    function getpart1papers($hallticket){
                global $conn;
                $query = "select * from  rholdernew where  RESULT NOT IN('F','AB') AND HALLTICKET='$hallticket' AND PART=1 ORDER BY PAPERCODE";
                // echo $query ."QUERY";
                $queryresult=$conn->query($query);
                $papers=array();
                //print_r($papers);
                while($sub=mysqli_fetch_assoc($queryresult)){
                    array_push($papers,$sub);
                };
                return $papers;
    }
    
    function getpart2papers($hallticket){
                global $conn;
                $query = "select * from  rholdernew where  RESULT NOT IN('F','AB') AND HALLTICKET='$hallticket' AND PART=2 ORDER BY PAPERCODE"; 
                $queryresult=$conn->query($query);
                $papers=array();
                //print_r($papers);
                while($sub=mysqli_fetch_assoc($queryresult)){
                    array_push($papers,$sub);
                };
                return $papers;
    }
            
    function getallpapers($hallticket){
                global $conn;
                $query = "select * from  rholdernew where  RESULT NOT IN('F','AB') AND HALLTICKET='$hallticket' ORDER BY PAPERCODE";
                
                $queryresult=$conn->query($query);
                $papers=array();
                //print_r($papers);
                while($sub=mysqli_fetch_assoc($queryresult)){
                    array_push($papers,$sub);
                };
                return $papers;
    }
            

    $getstudents="select ID,MEMO_NO,HALLTICKET,S1GPA,S2GPA,S3GPA,S4GPA,S5GPA,S6GPA,P1_YOP,P2_YOP,ALL_YOP,ADM_YEAR,REMARKS from grades";
    // echo $getstudents;
    $studentsresult=$conn->query($getstudents);
    while($student=mysqli_fetch_assoc($studentsresult)){
        $gpas=array();
        $consolidated=array();
        
        echo (implode($student,","));
        echo ",";
        $s1papers=getsempapers($student['HALLTICKET'],1);
        // print_r($s1papers);
        $s2papers=getsempapers($student['HALLTICKET'],2);
        $s3papers=getsempapers($student['HALLTICKET'],3);
        $s4papers=getsempapers($student['HALLTICKET'],4);
        $s5papers=getsempapers($student['HALLTICKET'],5);
        $s6papers=getsempapers($student['HALLTICKET'],6);


        $part1papers=getpart1papers($student['HALLTICKET']);
        $p1consolidated=consolidatereport($part1papers);
        
        $part2papers=getpart2papers($student['HALLTICKET']);
        $p2consolidated=consolidatereport($part2papers);
        
        $allpapers=getallpapers($student['HALLTICKET']);
        $overallconsolidated=consolidatereport($allpapers);
        
        
        
        // $gpas['sem1']=calcsgpa($s1papers);
        // $gpas['sem2']=calcsgpa($s2papers);
        // $gpas['sem3']=calcsgpa($s3papers);
        // $gpas['sem4']=calcsgpa($s4papers);
        // $gpas['sem5']=calcsgpa($s5papers);
        // $gpas['sem6']=calcsgpa($s6papers);
        $gpas['part1']=calcsgpa($part1papers);
        $gpas['part2']=calcsgpa($part2papers);
        $gpas['overall']=calcsgpa($allpapers);
        echo (implode($gpas,","));
        $part1cf=$p1consolidated['CF'];
        $p1div=$p1consolidated['DIVISION'];
        $part2cf=$p2consolidated['CF'];
        $p2div=$p2consolidated['DIVISION'];
        $overallcf=$overallconsolidated['CF'];
        $overalldiv=$overallconsolidated['DIVISION'];
        // print_r($p1consolidated);
        
        echo ",";
        // echo "p1";
        // print_r($p1consolidated);
        // echo "gpas";
        // print_r($gpas);
        // echo "p1cf";
        // print_r($part1cf);
        // echo "p2cf";
        // print_r($part2cf);
        // echo "ovcf";
        // print_r($overallcf);
        echo $part1cf.",";
        echo $part2cf.",";
        echo $overallcf.",";
        echo $p1div.",";
        echo $p2div.",";
        echo $overalldiv;
        echo "\n";
        
       
        
    }
    
?>
       