<script>
    // var p="july2021",r=prompt("Enter Report Password");r!=p&&(window.location.href="https://uascku.ac.in/404");
</script>
<?php
$db= isset($_GET['db']) ? $_GET['db'] :"atech_ebms2020" ;
function consolidatereport(
    $papers
) {
    $marks_sec = 0;
    $totalmarks = 0;
    $credit_total = 0;
    $gpc_total = 0;
    $gpcc_total = 0;
    $percentages = array();
    $cgpa_percentages = array();
    $failed_count = 0;
    $passedbyfloatation = false;
    $failedpapers = array();
    foreach ($papers as $paper) {
        if ($paper['GRADE'] == 'EX') {
            continue;
        }

        if ($paper['RESULT'] == 'F') {
            $failed_count++;
            array_push($failedpapers, $paper);
        }
        if ($paper['STATUS'] == "FL" || $paper['STATUS'] == "FL-" || $paper['STATUS'] == "FL AC") {
            $passedbyfloatation = $paper['STATUS'];
        }
        $gpc_total += $paper['GPC'];
        $credit_total += $paper['CREDITS'];
        $marks_sec += $paper['MARKS'];
        $totalmarks += $paper['TOTALMARKS'];
    }
    $result = array();
    $result['MARKS'] = $marks_sec;
    $result['TOTAL'] = $totalmarks;
    $result['gpc_total'] = $gpc_total;
    $result['credits'] = $credit_total;
    $result['SGPA'] = $gpc_total / $credit_total;
    $result['OGPA'] = $gpc_total / $credit_total;
    $per = $marks_sec / $totalmarks * 100;
    $cper = $result['OGPA'] * 10;
    $result['failed_count'] = $failed_count;
    $result['PERCENTAGE'] = $per;
    $result['cf'] = $per - $cper;
    if ($passedbyfloatation) {
        $result['passedbyfloatation'] = $passedbyfloatation;
    } else {
        $result['passedbyfloatation'] = "";
    }
    return $result;
}





?>

<style>
    * {
        font-family: arial;
    }

    .resulttable {
        margin-top: 0px;
        padding-bottom: 6px;
        width: 100%;
        page-break-inside: avoid;
    }

    hr {
        border: 1px dashed;
        margin-bottom: 2px;
    }

    td {
        font-size: <?php echo $_GET['fontsize']; ?>;
    }

    .student-title {
        padding: 0px;
        margin: 0px;
    }

    .watermark {
        display: none;
    }

    @media only print {
        .watermark {
            height: 100vh;
            width: 100%;
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
            position: fixed;
            top: 0;
            left: 0;
            z-index: -1000;
        }


    }
</style>
<h2 style="text-align:center">TABULATION REPORT</h2>
<H3 style="text-align:center"> EXAMINATION BRANCH <br>
    UNIVERSITY ARTS & SCIENCE COLLEGE,(AUTONOMOUS)<br>
    KAKATIYA UNIVERSITY- WARANGAL. TELANGANA
</H3>
<table style="width:100%" class="report">

    <tbody>
        <?php
        set_time_limit(1000);
        ini_set('display_errors', 1);
        include "../config.php";


        $conn = mysqli_connect($servername, $dbuser, $dbpwd, $db);

        if ($conn->connect_error) {
            die("connection failed:" . mysqli_connect_error());
        } else {
            $getstudents = "select DISTINCT(HALLTICKET),EXAMID,students.* from  PRERESULTS left join students on HALLTICKET=haltckt where students.COURSE='BA' ORDER BY HALLTICKET";
            
            $studentsresult = $conn->query($getstudents);
            while ($student = mysqli_fetch_assoc($studentsresult)) {
                echo "<tr>";
                echo "<hr>";
                echo "<h4 class='student-title'> HALLTICKET:  " . $student['HALLTICKET'] . "&nbsp;&nbsp;&nbsp;NAME: " . $student['sname'] . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  S/o&nbsp;D/o &nbsp;&nbsp;" . $student['fname'];
                echo '</h4>';
                echo "<hr></tr>";
        ?>
                <?php
                $getpapers = "SELECT * from PRERESULTS LEFT JOIN ALPHACODES ON PRERESULTS.PAPERCODE=ALPHACODES.NUMERICCODE WHERE EXAMID=" . $student['EXAMID'] . " and HALLTICKET='" . $student['HALLTICKET'] . "' ORDER BY PAPERCODE";
                $papers = $conn->query($getpapers);
                echo "<tr>";
                ?>
                <table>
                    <tr>
                        <td>
                            PCODE<br>
                            EXT:<br>
                            INT:<br>
                            TOT:<br>
                            RES:GR
                        </td>

                        <?php foreach ($papers as $paper) : ?>
                            <!--<pre>-->
                            <?php // print_r($paper); 
                            ?>
                            <!--</pre>-->
                            <td style="padding-right:1em">
                                <?php if ($paper['STATUS'] != NULL) : ?>
                                    <?= $paper['ALPHACODE'] ?>/<?= $paper['PAPERCODE'] ?><br>
                                    <?= $paper['EXT'] == "AB" ? "AB" : $paper['EXT']; ?> /
                                    <?= $paper['ETOTAL'] == "AB" ? "AB" : $paper['ETOTAL']; ?>
                                    <br>
                                    <?= $paper['INT'] == "AB" ? "AB" : $paper['INT'] ?> /
                                    <?= $paper['ITOTAL'] == "AB" ? "AB" : $paper['ITOTAL']; ?>
                                    <br>
                                    <?= $paper == "AB" ? "AB" : $paper['MARKS']  ?>/
                                    <?= $paper['TOTALMARKS'] ?>
                                    <br>
                                    <?= $paper['RESULT'] ?> ::
                                    <?= $paper['GRADE'] ?>
                                <?php else : ?>
                                    <?= $paper['ALPHACODE'] ?> / <?= $paper['PAPERCODE'] ?><br>
                                    <?= $paper['EXT'] == "AB" ? "AB" : str_pad($paper['EXT'], 3, "0", STR_PAD_LEFT); ?> /
                                    <?= $paper['ETOTAL'] == "AB" ? "AB" : str_pad($paper['ETOTAL'], 3, "0", STR_PAD_LEFT); ?>
                                    <br>
                                    <?= $paper['INT'] == "AB" ? "AB" : str_pad($paper['INT'], 3, "0", STR_PAD_LEFT); ?> /
                                    <?= $paper['ITOTAL'] == "AB" ? "AB" : str_pad($paper['ITOTAL'], 3, "0", STR_PAD_LEFT); ?>
                                    <br>
                                    <?= $paper == "AB" ? "AB" : str_pad($paper['MARKS'], 0, 3, STR_PAD_LEFT); ?>/
                                    <?= str_pad($paper['TOTALMARKS'], 3, "0", STR_PAD_LEFT); ?>
                                    <br>

                                    <?= $paper['RESULT'] ?> ::
                                    <?= $paper['GRADE'] ?>

                                <?php endif; ?>
                            </td>

                        <?php endforeach; ?>

                        <?php
                        $result = consolidatereport($papers);
                        ?>
                        <td>
                            <strong>
                                <?= $result['passedbyfloatation'] ?>
                            </strong><br>
                            <?= $result['MARKS'] ?>/<?= $result['TOTAL'] ?><br>
                            <?= round($result['PERCENTAGE'], 2); ?>%<br>
                            (<?= round($result['SGPA'], 2); ?>)


                        </td>
                    </tr>
                </table>



        <?php

                echo "<tr>";
            }
            // end of students
        }
        ?>
    </tbody>
</table>
<div class="watermark">
    <img src="http://uascku.ac.in/kulogo.jpg" style="opacity:0.1">
</div>