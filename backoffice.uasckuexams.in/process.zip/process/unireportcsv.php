<?php
header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
header("Content-type:   application/x-msexcel; charset=utf-8");
header("Content-Disposition: attachment; filename=abc.csv"); 
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Cache-Control: private",false);

include "config.php";
//check connection
    // $start=$_GET['start'];
    // if(isset($_GET['end'])){
    // $end=$_GET['end'];
    // }
    // else {
    //     $end=$start;
    // }
    $conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);
    
    if ($conn->connect_error) {
    die("connection failed:" . mysqli_connect_error());
    } 
    else{
    
    // $getstudents="select haltckt as HALLTICKET,sname,fname from students where haltckt='001171002'";
    // echo $getstudents;
    // $getstudents="select haltckt as HALLTICKET,sname,fname from students where haltckt in (001171497,001171502,001171507,001171513,001171518,001171804,001171806,001171811,001171812,001171816,001172002,001172014,001172018,001172023,001172037,001172046,001172302,001172317,001172329,001172334,001172605,001172613,001172617,001172621,001172625,001172633,001172637,001173006,001173013,001173023,001173028,001173048,001173049,001173207,001173214,001173217,001173606,001173615,001173631,001173815,001173932,001173934,001173936,001173939,001174004,001174010,001174033,001174205,001174225,001174419,001174425,001174601,001174603,001174607,001174610,001174612,001174801,001174807,001174829,001174924) order by haltckt";
     $getstudents="select grades.*,students.* FROM grades left join students on grades.HALLTICKET=students.haltckt ORDER BY grades.HALLTICKET";
    // $getstudents="select * FROM grades left join students on grades.HALLTICKET=students.haltckt ORDER BY HALLTICKET LIMIT 200,250";
    // echo $getstudents;
    
    
    
?>
  <?php  
        $studentsresult=$conn->query($getstudents);
        while($student=mysqli_fetch_assoc($studentsresult)){
                echo "HALLTICKET;". $student['HALLTICKET']. ";STUDENT NAME;" . $student['sname'] . "FATHER NAME;" . $student['fname'] . "\n";
                $getexamids="select distinct(rholdernew.EXAMID),examsmaster.SEMESTER,examsmaster.EXAMTYPE from rholdernew left join examsmaster on rholdernew.EXAMID=examsmaster.EXID where HALLTICKET=".$student['HALLTICKET']." order by examsmaster.SEMESTER,examsmaster.YEAR ";    
                // echo $getexamids;
                $examsresult=$conn->query($getexamids);
            
            while($exam=mysqli_fetch_assoc($examsresult)){
                
                 $getexamdetails=$conn->query("select * from examsmaster where EXID=".$exam['EXAMID']);
                 $exam=mysqli_fetch_assoc($getexamdetails);
                 echo "\n EXAM NAME ,",$exam['EXAMNAME']."\n";
                        $sql="SELECT `PAPERCODE`,`INT`,`EXT`,`GRADE`,`EID` FROM rholdernew WHERE HALLTICKET='".$student['HALLTICKET']."' AND EXAMID=".$exam['EXID']." ORDER BY PAPERCODE";
                        // echo $sql;
                        $result = $conn->query($sql);
                        $count=$result->num_rows;
                        while($count!=0){
                        echo 'PCODE,INT,EXT,GRADE,';
                        $count--;
                        }
                        echo "\n";
                        while($row=mysqli_fetch_assoc($result)){
                        echo ''.$row['PAPERCODE'].','.ROUND($row['INT']).','.$row['EXT'].','.$row['GRADE'].',';
                        }
                        $qsql="SELECT `TOTAL`,`RESULT`,`SGPA`,`CGPA` FROM gpas WHERE HALLTICKET='".$student['HALLTICKET']."' AND EXAMID=".$exam['EXID'];
                        $total= $conn->query($qsql);
                        
                        while($row=mysqli_fetch_assoc($total)){
                              echo "\n"."TOTAL ,". $row['TOTAL'].',';
                              echo 'RESULT , '.$row['RESULT'].',';
                            //   echo 'SGPA : '.$row['SGPA'].'';
                        }
                        echo "\n";
                        
                }
              
                  echo "\nResult\n";
                  echo "CGPA (PART-1)," . $student['P1CGPA'] ."," ;
                  echo "CGPA (PART-2) , ".$student['P2CGPA']. ",";
                  echo "CGPA (OVERALL) , ".$student['ALLCGPA'].",";
                  echo "CORRECTION FACTOR :, ". $student['ALLCF'].",";
                  echo "PASSED IN : ".$student['FINALDIV'].",";
                  echo "YEAR OF ADMISSION:".$student['ADM_YEAR']."\n";
                
            }//end of student
                  
                  
         
    }// end of students
    
    ?>
    