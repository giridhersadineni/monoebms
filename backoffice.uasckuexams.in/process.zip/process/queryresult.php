<?php include "../header.php";
include "../projectorm.php";
?>
<div class="page-wrapper p-3">
    <div class="row">
        <div class="col-12 p-2">
            <?php
            print_r($_POST);
            getdatatable($_POST['QUERY'],"display nowrap table table-hover table-striped table-bordered","example23",$action="view");
            ?>
            
        </div>
    </div>
</div>
<?php include "../datatablefooter.php";?>