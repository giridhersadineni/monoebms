<?php include "header.php" ;?>
<div class="page-wrapper d-flex">
    <div class="card">
        Tabulation Links
        <h3>Combined</h3>
        <p><a href="finaltabulation.php?db=atech_ebms2020"> FINAL Tabulation 2020 </a></p>
        <p><a href="finaltabulation.php?db=atech_ebms" >Final Tabulation OLD</a></p>
        
        <h3>BA</h3>
        
        <p><a href="bafinaltabulation.php?db=atech_ebms2020"> FINAL Tabulation 2020 </a></p>
        <p><a href="bafinaltabulation.php?db=atech_ebms" >Final Tabulation OLD</a></p>
        
        <h3>BCOM</h3>
        <p><a href="bcomfinaltabulation.php?db=atech_ebms2020"> FINAL Tabulation 2020 </a></p>
        <p><a href="bcomfinaltabulation.php?db=atech_ebms" >Final Tabulation OLD</a></p>
        
        <h3>BSC</h3>
        <p><a href="bscfinaltabulation.php?db=atech_ebms2020"> FINAL Tabulation 2020 </a></p>
        <p><a href="bscfinaltabulation.php?db=atech_ebms" >Final Tabulation OLD</a></p>
        
        <h3>FINAL RESULT</h3>
        <p><a href="finalresult.php?db=atech_ebms2020"> FINAL RESULT 2020 </a></p>
        <p><a href="finalresult.php?db=atech_ebms" >FINAL RESULT OLD</a></p>
        
        
 </div>           
</div>
<div class="page-wrapper d-flex">
  
                                      
    <div class="card col-3 m-2"><a href="bosreport.php" class="stretched-link">BOS Report</a></div>
    <div class="card col-3 m-2"><a href="premoderation.php" class="stretched-link">Premoderation Report</a></div>
    <div class="card col-3 m-2"><a href="floatationreport.php" class="stretched-link"> Floatation Report</a></div>
    <div class="card col-3 m-2"><a href="postmoderation.php" class="stretched-link">Post Moderation Report</a></div>
    <div class="card col-3 m-2"><a href="finaltabulation.php" class="stretched-link">Final Tabulation</a></div>
    
    
</div>



<?php include "footer.php" ;?>