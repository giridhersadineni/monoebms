<?php include "../header.php";
include "../projectorm.php";
$db=isset($_GET['db'])?$_GET['db']:"atech_ebms2020"; 

$query = "Select * from $db.GPAS_STAGE left join $db.students on $db.GPAS_STAGE.HALLTICKET=$db.students.haltckt";
?>

<div class="page-wrapper p-3">
    <div class="row">
        <div class="col-12 p-2">
            <?php
            
            getdatatable($query,"display nowrap table table-hover table-striped table-bordered","example23",$action="view");
            ?>
            
        </div>
    </div>
</div>
<?php include "../datatablefooter.php";?>