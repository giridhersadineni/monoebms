<?php 
header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
header("Content-type:   application/x-msexcel; charset=utf-8");
header("Content-Disposition: attachment; filename=floatationreport.csv"); 
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Cache-Control: private",false);
$db= isset($_GET['db']) ? $_GET['db'] :"atech_ebms" ;

include "domainfunctions.php"; 
?>

        <?php
        set_time_limit(1000);
        ini_set('display_errors', 1);
        include "../config.php";
        $conn = mysqli_connect($servername, $dbuser, $dbpwd, $db);
        if ($conn->connect_error) {
            die("connection failed:" . mysqli_connect_error());
        } else {
        $getstudents = "select DISTINCT(HALLTICKET),EXAMID,students.* from  RESULTS_POSTMOD left join students on HALLTICKET=haltckt ORDER BY EXAMID,HALLTICKET";
        $studentsresult = $conn->query($getstudents);
        while ($student = mysqli_fetch_assoc($studentsresult)) {
           
            
         $floatingApplicable=isFloatationApplicable($student['HALLTICKET'],$student['EXAMID']);
         if($floatingApplicable==true) {
         

         echo_csv($student);
         
        $getpapers = "SELECT RESULTS_POSTMOD.*,ALPHACODES.ALPHACODE from RESULTS_POSTMOD LEFT JOIN ALPHACODES ON `RESULTS_POSTMOD`.`PAPERCODE` =`ALPHACODES`.`NUMERICCODE` WHERE EXAMID=". $student['EXAMID'] . " and HALLTICKET='" . $student['HALLTICKET']. "' ORDER BY RESULT, PART";
         // echo $getpapers;
        $papers = $conn->query($getpapers);
     
        ?>

    <?php foreach($papers as $paper):?>
    
        <?php  echo_csv($paper); ?>
    
    <?php endforeach; ?>
   
<?php }}} ?>