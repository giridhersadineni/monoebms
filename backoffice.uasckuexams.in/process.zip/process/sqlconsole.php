

<html>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css">
    </head>
    <script>
            var p="sadineni@1990",r=prompt("Enter Report Password");r!=p&&(window.location.href="https://uascku.ac.in/404");
    </script>
</html>

<div class="page-wrapper p-3 bg-secondary">
    <div class="row">
        <div class="col-12 ">
            <div class="card">
                
            <div class="card-header text-primary">
                <h2>EBMS DATA CONSOLE</h2>
            </div>
            
            <form method="POST" action="queryresult.php">
                <h4>Enter the Query</h4>
                <textarea class="form-control w-100" cols="100" rows="6" name="QUERY"></textarea>
                <p class="text-right p-3">
                    <input type="submit" class="btn btn-success">
                </p>
            </form>
            
            </div>
        </div>
</div>
    