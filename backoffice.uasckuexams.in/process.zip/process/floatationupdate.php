<?php 

include "../domain/domainfunctions.php" ; 

$query= "select * from atech_ebms.`TABLE 42`";
$data=get_result_array($query);
echo "START TRANSACTION;";
foreach($data as $row){

    $action=$row['MARKTYPE'];
    switch($action){
        case "FLADD":
            $query="UPDATE PRERESULTS SET EXT= EXT + ".$row['MARKS'].", STATUS='FL',MARKER='FL' WHERE CODE=".$row['SCRIPTCODE']." AND PAPERCODE='".$row['PAPERCODE']."' AND HALLTICKET='".$row['HALLTICKET']."'";
            break;
        
        case "SUB":
            $query="UPDATE PRERESULTS SET EXT= EXT - ".$row['MARKS'].", STATUS='FL',MARKER='FL-' WHERE CODE=".$row['SCRIPTCODE']." AND PAPERCODE='".$row['PAPERCODE']."' AND HALLTICKET='".$row['HALLTICKET']."'";
            break;
        case "ACADD":
            case "FLADD":
            $query="UPDATE PRERESULTS SET EXT= EXT + ".$row['MARKS'].", STATUS='FL AC',MARKER='FL-' WHERE CODE=".$row['SCRIPTCODE']." AND PAPERCODE='".$row['PAPERCODE']."' AND HALLTICKET='".$row['HALLTICKET']."'";
            break;
    }
    echo $query ,";\n";
    
}
echo "COMMIT;";

?>
