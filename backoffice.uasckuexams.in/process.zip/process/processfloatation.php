<?php 
        $db= isset($_GET['db']) ? $_GET['db'] :"atech_ebms" ;
        $table="atech_ebms.RESULTS_FLOATATION";
        include "domainfunctions.php"; 
        
        function get_floatation_paper($papers){
            foreach($papers as $paper){
                if($paper['RESULT']=='F'){
                    return $paper;
                }
            }
        }
        
        
        function getmaxpaperbypart($papers,$papertofloat){
            $maxmarks=0;
            $maxpaper=array();
            foreach($papers as $paper){
                if($paper['EXT'] > $maxmarks && $paper['PART']==$papertofloat['PART']){
                    $maxmarks=$paper['EXT'];
                    $maxpaper=$paper;
                }
            }
            return $maxpaper;
        }
        
        function getmaxpaper($papers,$papertofloat){
            $maxmarks=0;
            $maxpaper=array();
            foreach($papers as $paper){
                if($paper['EXT'] > $maxmarks){
                    $maxmarks=$paper['EXT'];
                    $maxpaper=$paper;
                }
            }
            return $maxpaper;
        }
        
        
        function getFloatationMarkNeeded($papertofloat){
            $passmarks = $papertofloat['ETOTAL'] * 0.40;
            $marksrequired=$passmarks-$papertofloat['EXT'];
            // check how many marks required
            $returndata = array();
            
            //build return object
            $returndata['floatmarks']=0;
            $returndata['acmarks']=0;
            $returndata['acmarkneeded']=false;
            
            if( $marksrequired < 0 ){
                // if student doesnt have internal marks he should pass with external marks only
                $passmarks = $papertofloat['TOTALMARKS'] * 0.40;
            }
            else{
                $passmarks = $papertofloat['ETOTAL'] * 0.40;
            }
            $marksrequired=$passmarks-$papertofloat['EXT'];
            if($marksrequired > $papertofloat['ETOTAL'] * 0.05){
                $returndata['floatmarks']=$marksrequired-1;
                $returndata['acmarks']=1;
                $returndata['acmarkneeded']=true;
            }
            else{
                $returndata['floatmarks']=$marksrequired;
                $returndata['acmarks']=0;
                $returndata['acmarkneeded']=false;
            }
            
            return $returndata;
        }
        
        
        
        
        function IsPassedAfterDeduction($paper,$markstodeduct){
            $temp=$paper;
            $temp['EXT']=$temp['EXT']-$markstodeduct;
            echo "<br>Checking Paper<br>";
            echo implode($paper,"  ");
            $updatedPaper=calculatePaperResult($temp);
            if($updatedPaper['RESULT']=='F'){
                return false;
            }
            return true;
        }
        
        
        
        set_time_limit(1000);
        ini_set('display_errors', 1);
        include "../config.php";
        $conn = mysqli_connect($servername, $dbuser, $dbpwd, $db);
        if ($conn->connect_error) {
            die("connection failed:" . mysqli_connect_error());
        } else {
        $getstudents = "select DISTINCT(HALLTICKET),EXAMID,students.* from  RESULTS_FLOATATION left join students on HALLTICKET=haltckt ORDER BY EXAMID,HALLTICKET";
        $studentsresult = $conn->query($getstudents);
        while ($student = mysqli_fetch_assoc($studentsresult)) {
           
            
         $floatingApplicable=isFloatationApplicable($student['HALLTICKET'],$student['EXAMID']);
         if($floatingApplicable==true) {
        //echo_csv($student);
         
        $getpapers = "SELECT RESULTS_FLOATATION.*,ALPHACODES.ALPHACODE from RESULTS_FLOATATION LEFT JOIN ALPHACODES ON `RESULTS_FLOATATION`.`PAPERCODE` =`ALPHACODES`.`NUMERICCODE` WHERE EXAMID=". $student['EXAMID'] . " and HALLTICKET='" . $student['HALLTICKET']. "' ORDER BY RESULT, PART";
        // echo $getpapers;
        $papers = get_result_array($getpapers);
        ?>

        <?php 
        echo "<br>----------------------------------------------------------------------------<br>";
        foreach($papers as $paper):?>
         <?php 
           
            echo implode($paper,"  ") . "<br>" ; 
            //print_formatted($paper);
         ?> 
        <?php endforeach; ?>
        
        <?php
        
            $papertodeduct=array();
            $secondpapertodeduct=array();
        
            echo "Floatation Paper"."<br>";
            $papertofloat=get_floatation_paper($papers);
            echo implode($papertofloat," ");
            $marksRequired=getFloatationMarkNeeded($papertofloat);
            echo "<br>  Marks Required <br> Floatation ".$marksRequired['floatmarks'] . "<br> AC Mark ". $marksRequired['acmarks']; 
            // break;  // end of student records
            $papertodeduct=getmaxpaperbypart($papers,$papertofloat);
            var_dump($marksRequired);
            if($marksRequired['acmarkneeded']==true){
                $canDeductFromSinglePaper=IsPassedAfterDeduction($papertodeduct,$marksRequired['floatmarks']);
            }
            else{
                $canDeductFromSinglePaper=IsPassedAfterDeduction($papertodeduct,$marksRequired['floatmarks']);
            }
            if($canDeductFromSinglePaper==true){
                echo "<br>Can Deduct From Paper"."<br>";
                echo implode($papertodeduct,"   ");
            }
            else{
                echo "<br>Cannot Deduct From Single Paper"."<br>";
                $papertodeduct=getmaxpaperbypart($papers,$papertofloat);
                $temppapers=array();
                //remove already picked paper
                foreach($papers as $p){
                    
                    if( $p['RHID'] == $papertodeduct['RHID'] ){   }
                    else{
                        array_push($temppapers,$p);
                    }
                }
                $secondpapertodeduct = getmaxpaperbypart($temppapers,$papertofloat);
            }
            
            echo "<br>-------------------------------------------------------------------------------<br>";
            echo "<br>First Paper<br>" . implode($papertodeduct, "   ");
            echo "<br>Second Paper<br>" . implode($secondpapertodeduct,"  ");
            echo "<br><br>";
            
           $papertofloat['EXT'] = $papertofloat['EXT'] + $marksRequired['floatmarks'] + $marksRequired['acmarks'];
           $papertofloat['STATUS']=$marksRequired['acmarks']>0 ?'FL AC' : "FL";
            
           $papertodeduct['EXT'] = $papertodeduct['EXT'] - $marksRequired['floatmarks'];
           $papertodeduct['STATUS']="FL -";
           
           
           echo " <br> Floatation Done for <br>" . implode($papertofloat , "   ");
           echo " <br> Deducted From <br>" . implode($papertodeduct , "  ");
           
          // echo $updated=updatePaperByTable($papertofloat,$table);
           // echo $deducted=updatePaperByTable($papertodeduct,$table);
            
         }
        }
        } 
        ?>

