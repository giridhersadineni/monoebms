<?php
$servername = "localhost";
$dbuser = "atech_ebmsarts";
$dbpwd = "giridhersadineni";
$dbname = "atech_ebms";
//connection 


?> 